var begin = 11.438;
var tel = setTimeout(tellen, 500);

document.getElementById("counter").innerHTML = "Aantal Pangolins gered: " + totaal;



function tellen() {
    totaal = begin + Math.floor((Math.random() * 10) + 8);
    document.getElementById("counter").innerHTML = "Aantal Pangolins gered: " + totaal;
    optellen()
}

function optellen(){
    tel
}